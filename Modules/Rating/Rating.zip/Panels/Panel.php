<?php

/**
 * NOTICE OF LICENSE
 *
 * This source file is part of AmhsoftFrameWork
 * AmhsoftFrameWork is a commercial software
 *
 * $Id: index.class.php 879 2011-06-20 04:31:08Z Montasser $
 * $Rev: 879 $
 * @package    Rating
 * @copyright  2005-2014 (c) AMHSOFT e.K. (Web & Software Solutions) Germany (http://www.Amhsoft.com)
 * @license    Amhsoft FrameWork is a commercial software
 * $Date: 
 * $LastChangedDate: 2011-06-20 06:31:08 +0200 (Mo, 20. Jun 2011) $
 * $Author: Montasser $
 */
class Rating_Panel extends Amhsoft_Widget_Panel {

  public $nameLabel;
  public $rateLabel;
  public $commentLabel;
  public $ipLabel;

  /**
   * Panel Construct
   */
  public function __construct() {
    parent::__construct();
    $this->initializeComponents();
  }

  /**
   * Initialize Panel Components
   */
  public function initializeComponents() {
    $layout = new Amhsoft_Grid_Layout(1);
    $panelInformation = new Amhsoft_Widget_Panel(_t('General Information'));
    $panelInformation->setLayout($layout);
    $this->nameLabel = new Amhsoft_Label_Control(_t('Name'), new Amhsoft_Data_Binding('name'));
    $this->rateLabel = new Amhsoft_Label_Control(_t('Rate'), new Amhsoft_Data_Binding('rate'));
    $this->commentLabel = new Amhsoft_Label_Control(_t('Comment'), new Amhsoft_Data_Binding('comment'));
    $this->ipLabel = new Amhsoft_Label_Control(_t('IP'), new Amhsoft_Data_Binding('ip'));
    $panelInformation->addComponent($this->nameLabel);
    $panelInformation->addComponent($this->rateLabel);
    $panelInformation->addComponent($this->ipLabel);
    $panelInformation->addComponent($this->commentLabel);
    $this->addComponent($panelInformation);
  }

}

?>
