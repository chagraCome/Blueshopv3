<?php

/* * *********************************************************************************************
 * NOTICE OF LICENSE
 *
 * This source file is part of AMHSHOP (E-Commerce Solution)
 * AMHSHOP is a commercial software
 *
 * $Id: index.php 5 2011-10-19 09:16:11Z cherif $
 * $Rev: 5 $
 * @package    Rating
 * @copyright  2006-2014 (c) AMHSOFT e.K. (Web & Software Solutions) Germany (http://www.amhsoft.com)
 * @license    AMHSHOP is a commercial software
 * $Date: 2011-10-19 11:16:11 +0200 (Mi, 19 Okt 2011) $
 * $LastChangedDate: 2011-10-19 11:16:11 +0200 (Mi, 19 Okt 2011) $
 * $Author: cherif $
 * *********************************************************************************************** */

class Modules_Rating_Backend_Boot extends Amhsoft_System_Module_Abstract {

    /**
     * Initialize Module Menu Container
     * @param Amhsoft_System $system
     */
    public function onInitMenuContainer(Amhsoft_System $system) {
        $admin = $system->getMenuContainer()->findMenuByName("Rating");
        $admin->setLabel(_t("Rating"));
        $admin->AddItem(new Amhsoft_Widget_Menu_Item(_t("Manage Rating Comments"), "admin.php?module=rating&page=list"));
    }

    /**
     * On Module Install
     * @param Amhsoft_System $system
     * @return boolean
     */
    public function onInstall(Amhsoft_System $system) {
        $file = dirname(dirname(__FILE__)) . '/Install/mysql.sql';
        try {
            $this->executeSQLFile($file);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Init RBAC Rules.
     * @param Amhsoft_System $system
     */
    public function initRBAC(Amhsoft_System $system) {
        $system->registerRBACRule(new Amhsoft_RBAC_Rule('Rating', _t('Rating Module'), null));
        $system->registerRBACRule(new Amhsoft_RBAC_Rule('Rating_Backend_Delete_Controller', _t('Delete Rating'), 'Rating'));
        $system->registerRBACRule(new Amhsoft_RBAC_Rule('Rating_Backend_Details_Controller', _t('Details Rating'), 'Rating'));
        $system->registerRBACRule(new Amhsoft_RBAC_Rule('Rating_Backend_List_Controller', _t('List all Rating'), 'Rating'));
        $system->registerRBACRule(new Amhsoft_RBAC_Rule('Rating_Backend_Offline_Controller', _t('Offline Rating'), 'Rating'));
        $system->registerRBACRule(new Amhsoft_RBAC_Rule('Rating_Backend_Online_Controller', _t('Online Rating'), 'Rating'));
    }

    /**
     * Tables To Backup
     * @return type
     */
    public function getTablesToBackup() {
        return array(
            'entity_rating',
        );
    }

}

?>
