<?php

/* * *********************************************************************************************
 * NOTICE OF LICENSE
 *
 * This source file is part of AMHSHOP (E-Commerce Solution)
 * AMHSHOP is a commercial software
 *
 * $Id: index.php 5 2011-10-19 09:16:11Z cherif $
 * $Rev: 5 $
 * @package    Rating
 * @copyright  2006-2014 (c) AMHSOFT e.K. (Web & Software Solutions) Germany (http://www.amhsoft.com)
 * @license    AMHSHOP is a commercial software
 * $Date: 2011-10-19 11:16:11 +0200 (Mi, 19 Okt 2011) $
 * $LastChangedDate: 2011-10-19 11:16:11 +0200 (Mi, 19 Okt 2011) $
 * $Author: cherif $
 * *********************************************************************************************** */

class Rating_Backend_Offline_Controller extends Amhsoft_System_Web_Controller {

  /**
   * Initialize Event
   * @throws Amhsoft_Item_Not_Found_Exception
   */
  public function __initialize() {
    $id = $this->getRequest()->getId();
    if ($id > 0) {
      $ratingModelAdapter = new Rating_Model_Adapter();
      $ratingModel = $ratingModelAdapter->fetchById($id);
      if ($ratingModel instanceof Rating_Model) {
	$ratingModel->setState(0);
	$ratingModelAdapter->save($ratingModel);
	$this->getRedirector()->go(Amhsoft_History::back() . '&ret=true');
      }
    } else {
      throw new Amhsoft_Item_Not_Found_Exception();
    }
  }

  /**
   * Default Event
   */
  public function __default() {
    
  }

  /**
   * Finalize Event
   */
  public function __finalize() {
    
  }

}

?>
