<?php

/* * *********************************************************************************************
 * NOTICE OF LICENSE
 *
 * This source file is part of AMHSHOP (E-Commerce Solution)
 * AMHSHOP is a commercial software
 *
 * $Id: add.class.php 505 2012-03-08 12:12:18Z cherif $
 * $Rev: 505 $
 * @package    Rating
 * @copyright  2006-2014 (c) AMHSOFT e.K. (Web & Software Solutions) Germany (http://www.amhsoft.com)
 * @license    AMHSHOP is a commercial software
 * $Date: 2012-03-08 13:12:18 +0100 (Do, 08 Mrz 2012) $
 * $LastChangedDate: 2012-03-08 13:12:18 +0100 (Do, 08 Mrz 2012) $
 * $Author: cherif $
 * *********************************************************************************************** */

class Rating_Frontend_Add_Controller extends Amhsoft_System_Web_Controller {

  /** @var Rating_Form ratingForm */
  protected $ratingForm;

  /** @var Rating_Model ratingModel */
  protected $ratingModel;

  /**
   * Initialize Controller
   */
  public function __initialize() {
    $this->ratingForm = new Rating_Form('ratingForm_form', 'POST');
    $this->ratingModel = new Rating_Model();
    $this->getView()->setMessage(_t('Add new Rating'), View_Message_Type::INFO);
  }

  /**
   * Default Event
   */
  public function __default() {
    $this->ratingForm->DataSource = Amhsoft_Data_Source::Post();
    if ($this->ratingForm->isSend()) {
      if ($this->ratingForm->isValid()) {
	$this->ratingForm->DataBinding = $this->ratingModel;
	$ratingModelAdapter = new Rating_Model_Adapter();
	$this->ratingModel = $this->ratingForm->getDataBindItem();
	$this->ratingModel->setComment(strip_tags($this->ratingModel->getComment()));
	$this->ratingModel->rate_date_time = Amhsoft_Locale::UCTDateTime();
	$this->ratingModel->setIp(Amhsoft_Common::GetClientIp());
	$ratingModelAdapter->save($this->ratingModel);
	$this->handleSuccess();
      } else {
	$this->getView()->setMessage(_t('Please check inputs.'), View_Message_Type::ERROR);
      }
    }
  }

  /**
   * Handle success.
   */
  protected function handleSuccess() {
    Amhsoft_Navigator::go(Amhsoft_History::back(1));
  }

  /**
   * Finalize Event
   */
  public function __finalize() {
    $this->includeJsFile('Amhsoft/Ressources/Javascripts/JQuery/rating/jquery.rating.pack.js', false);
    $this->includeCssFile('Amhsoft/Ressources/Javascripts/JQuery/rating/jquery.rating.css', false);
    $this->getView()->assign('widget', $this->ratingForm);
    $this->show();
  }

}

?>