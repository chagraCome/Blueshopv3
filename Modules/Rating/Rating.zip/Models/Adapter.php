<?php

/**
 * NOTICE OF LICENSE
 *
 * This source file is part of AmhsoftFrameWork
 * AmhsoftFrameWork is a commercial software
 *
 * $Id: index.class.php 879 2011-06-20 04:31:08Z Montasser $
 * $Rev: 879 $
 * @package    Rating
 * @copyright  2005-2014 (c) AMHSOFT e.K. (Web & Software Solutions) (http://www.Amhsoft.com)
 * @license    Amhsoft FrameWork is a commercial software
 * $Date: 
 * $LastChangedDate: 2012-11-07 13:22:00 +0100 (mer., 07 nov. 2012) $
 * $Author: Montasser $
 */
class Rating_Model_Adapter extends Amhsoft_Data_Db_Model_Adapter {

  /**
   * Model Adapter Construct
   */
  public function __construct() {
    $this->table = 'entity_rating';
    $this->className = 'Rating_Model';
    $this->map = array('id' => 'id',
	'entity_id' => 'entity_id',
	'entity_class' => 'entity_class',
	'rate' => 'rate',
	'name' => 'name',
	'comment' => 'comment',
	'rate_date_time' => 'rate_date_time',
	'ip' => 'ip',
	'state' => 'state',
    );
    parent::__construct();
  }

}

?>