<?php

/**
 * NOTICE OF LICENSE
 *
 * This source file is part of AmhsoftFrameWork
 * AmhsoftFrameWork is a commercial software
 *
 * $Id: index.class.php 879 2011-06-20 04:31:08Z Montasser $
 * $Rev: 879 $
 * @package    Rating
 * @copyright  2005-2014 (c) AMHSOFT e.K. (Web & Software Solutions) Germany (http://www.Amhsoft.com)
 * @license    Amhsoft FrameWork is a commercial software
 * $Date: 
 * $LastChangedDate: 2012-11-07 13:22:00 +0100 (mer., 07 nov. 2012) $
 * $Author: Montasser $
 */
class Rating_Model implements Amhsoft_Data_Db_Model_Interface {

  public $id;
  public $entity_id;
  public $entity_class;
  public $rate;
  public $name;
  public $comment;
  public $rate_date_time;
  public $ip;
  public $state;

  /**
   * Gets id.
   * @return 
   * */
  public function getId() {
    return $this->id;
  }

  /**
   * Set id.
   * @param  id 
   * @return 
   * */
  public function setId($id) {
    $this->id = $id;
    return $this;
  }

  /**
   * Gets entity.
   * @return 
   * */
  public function getEntityId() {
    return $this->entity_id;
  }

  /**
   * Set entity.
   * @param  entity 
   * @return 
   * */
  public function setEntityId($entityId) {
    $this->entity_id = $entityId;
    return $this;
  }

  /**
   * Gets entity_class.
   * @return 
   * */
  public function getEntityClass() {
    return $this->entity_class;
  }

  /**
   * Set entity_class.
   * @param  entity_class 
   * @return 
   * */
  public function setEntityClass($entity_class) {
    $this->entity_class = $entity_class;
    return $this;
  }

  /**
   * Gets rate.
   * @return 
   * */
  public function getRate() {
    return $this->rate;
  }

  /**
   * Set rate.
   * @param  rate 
   * @return 
   * */
  public function setRate($rate) {
    $this->rate = $rate;
    return $this;
  }

  /**
   * Gets name.
   * @return 
   * */
  public function getName() {
    return $this->name;
  }

  /**
   * Set name.
   * @param  name 
   * @return 
   * */
  public function setName($name) {
    $this->name = $name;
    return $this;
  }

  /**
   * Gets comment.
   * @return 
   * */
  public function getComment() {
    return $this->comment;
  }

  /**
   * Set comment.
   * @param  comment 
   * @return 
   * */
  public function setComment($comment) {
    $this->comment = $comment;
    return $this;
  }

  /**
   * Gets rate_date_time.
   * @return 
   * */
  public function getRateDateTime() {
    return $this->rate_date_time;
  }

  /**
   * Set rate_date_time.
   * @param  rate_date_time 
   * @return 
   * */
  public function setRateDateTime($rate_date_time) {
    $this->rate_date_time = $rate_date_time;
    return $this;
  }

  /**
   * Gets ip.
   * @return 
   * */
  public function getIp() {
    return $this->ip;
  }

  /**
   * Set ip.
   * @param  ip 
   * @return 
   * */
  public function setIp($ip) {
    $this->ip = $ip;
    return $this;
  }

  /**
   * Get Rate Component
   * @return \Amhsoft_Rating_Control
   */
  public function getRateComponent() {
    $rateControl = new Amhsoft_Rating_Control('rate' . $this->getId(), _t('Rate'));
    $rateControl->Value = $this->getRate();
    $rateControl->Disabled = true;
    return $rateControl;
  }

  /**
   * Get State
   * @return type
   */
  public function getState() {
    return $this->state;
  }

  /**
   * Set State
   * @param type $state
   */
  public function setState($state) {
    $this->state = $state;
  }

}

?>