<?php
//Modules/Rating/Frontend/Views/Helpers/Rating.html
_t('Comment and Rating');
_t('Quality');
//Modules/Rating/Frontend/Views/Add.html
//Modules/Rating/Backend/Views/Details.html
_t('Information');
//Modules/Rating/Backend/Views/List.html
_t('Information');
